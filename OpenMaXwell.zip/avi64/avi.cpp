// Copyright 2009, 2009 Christian Hafner
//
// This file is part of OpenMaX.
//
// OpenMaX is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// OpenMaX is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// You should have received a copy of the GNU General Public License
// along with OpenMaX.  If not, see <http://www.gnu.org/licenses/>.
#include "stdafx.h"

// #include "avi.h"

#include <windows.h>
#include <vfw.h>
#include <crtdbg.h>
#include <winuser.h>
#include <stdio.h>
extern "C" {
	#include "dibapi.h"
}

	//  INTEGER*4 FUNCTION OPENAVIFILE(fileName, width, height, nrOfFrames, framesPerSecond)
	//  CHARACTER*(*) fileName
	//	INTEGER*4 width, height
	//	INTEGER*4 nrOfFrames, framesPerSecond
extern "C"	__declspec(dllexport) int OPENAVIFILE(int* iCompresed, char* fileName, int* fileNameSize,
			int* width, int* height, int* pNrOfFrames, int* pFramesPerSecond);

	//  INTEGER*4 FUNCTION WRITEAVIFRAME(frame)
	//	INTEGER*1(*) templateFrame
extern "C"	__declspec(dllexport) int WRITEAVIFRAME(BITMAPFILEHEADER* pHeader, COLORREF* pPalette, int* paletteSize);

	//  INTEGER*4 FUNCTION CLOSEAVIFILE()
extern "C"	__declspec(dllexport) int CLOSEAVIFILE();

static BOOL isInitialized = FALSE;
static PAVIFILE aviFile = NULL;
static PAVISTREAM videoStream = NULL;
static PAVISTREAM videoStreamCompressed = NULL;
static BOOL isFormatSet = FALSE;
char*  ErrorMessage;
static int framesWritten = 0;

AVICOMPRESSOPTIONS opts;
AVICOMPRESSOPTIONS FAR * aopts[1] = {&opts};

//-------------------------------------------------------------------------------------------------

__declspec(dllexport)int  OPENAVIFILE(int* iCompresed, char* fileName, int* fileNameSize,
		int* width, int* height, int* pNrOfFrames, int* pFramesPerSecond)
/*
		Opens an AVI file and a video stream within.
		The filename must be terminated with a null character.
		The total number of frames that you plan to write must be specified here, as well as
		the nominal frame rate.
*/
{
	HRESULT result;
	INT_PTR iresult;
//	fileName = "test.avi";
	_ASSERT(isInitialized == FALSE);
	_ASSERT(aviFile == NULL);
	framesWritten = 0;
    isFormatSet = FALSE;
  //  The stream format consists of DIB attributes and a palette.
  //  Setting the stream format is delayed until we write the first frame,
  //  because we will know the bitmap format by that time only.
	AVIFileInit();
	isInitialized = TRUE;


	result=DeleteFile(fileName);
	result = AVIFileOpen(&aviFile, fileName, OF_CREATE | OF_WRITE, NULL);
	if (result != 0) {
		return result;
	}
	AVISTREAMINFO si;
	si.fccType = streamtypeVIDEO;
  //  We use run-length encoding (RLE) to compress each frame,
  //  record this in the file header as well:
	si.fccHandler = mmioFOURCC('M','R','L','E');
	si.dwFlags = 0; 
	si.dwCaps = 0; 
	si.wPriority = 0; 
	si.wLanguage = 0; 
	si.dwScale = 1; 
	si.dwRate = 5; //*pFramesPerSecond;
	si.dwStart = 0;
	si.dwLength = 1000000; //*pNrOfFrames; 
	si.dwInitialFrames = 0; 
	si.dwSuggestedBufferSize = 0; 
	si.dwQuality = 10000;
	si.dwSampleSize = 0; 
	si.rcFrame.left = 0; 
	si.rcFrame.top = 0; 
	si.rcFrame.right = *width; 
	si.rcFrame.bottom = *height; 
	si.dwEditCount = 0; 
	si.dwFormatChangeCount = 0; 
	si.szName[0] = '\0';
	result = AVIFileCreateStream(aviFile, &videoStream, &si);
	if (result != 0) 
	{
		ErrorMessage="Can't make compressed stream";
		return result;
	}
//---------------------------------------------------
	HWND Owner = FindWindow(NULL,"Max07a"); 

	if (*iCompresed==1) 
	{
      *iCompresed=0;
	  memset(&opts, 0, sizeof(opts));
   	  iresult =AVISaveOptions(Owner, 0, 1, &videoStream, (LPAVICOMPRESSOPTIONS FAR *) &aopts);
	  if (!iresult) 
	  {

	 	 result=!result;
		 ErrorMessage="Can't save options";
   		 goto error;
	  } 
	}
    result = AVIMakeCompressedStream(&videoStreamCompressed, videoStream, &opts, NULL);
	if (result != AVIERR_OK) 
	{ 		 
	  ErrorMessage="Can't make compressed stream";
	  goto error;
	} 
//---------------------------------------------------
	return 0;
error:
	if (videoStream) 	       AVIStreamClose(videoStream);
	if (videoStreamCompressed) AVIStreamClose(videoStreamCompressed);
	if (aviFile)			   AVIFileClose(aviFile);	
	isInitialized =FALSE;
	aviFile=FALSE; 
	AVIFileExit();
	if (result != NOERROR)  	MessageBox(Owner,(LPCTSTR)ErrorMessage,NULL,MB_OK | MB_ICONERROR);
	return result;
}

__declspec(dllexport) int WRITEAVIFRAME(BITMAPFILEHEADER* pHeader, COLORREF* pPalette, int* paletteSize)
/*
		Writes a frame to an open video stream in an AVI file.
		The frame is given in a bitmap buffer as filled in from
		QuickWin GETIMAGE.
*/
{
	_ASSERT(aviFile != NULL && videoStreamCompressed != NULL);
	_ASSERT(pHeader->bfType == ('B' | ('M' << 8)));

	HRESULT result = 0;
	LONG lSampWritten = 0;
	LONG lBytesWritten = 0; 

  //  Point past the BITMAPFILEHEADER to the BITMAPINFOHEADER:
	BITMAPINFO* pbmi = (BITMAPINFO*)(pHeader + 1);
	if(*paletteSize >= 0) {
	  for (int c = 0; c < *paletteSize; c++) {
          pbmi->bmiColors[c+10].rgbRed   = GetRValue(pPalette[c]);
          pbmi->bmiColors[c+10].rgbGreen = GetGValue(pPalette[c]);
          pbmi->bmiColors[c+10].rgbBlue  = GetBValue(pPalette[c]);
	  }
	}
	BITMAPINFOHEADER* pDIB = &(pbmi->bmiHeader);

//  Compress the original bitmap (RLE), giving a new bitmap:

	BITMAPINFOHEADER* pNewDIB = NULL;
	
	HDIB hNewDIB = ChangeDIBFormatFromPDIB((LPSTR)pDIB, 256, BI_RLE8);

	if (hNewDIB != NULL) 
	{
		  pNewDIB = (BITMAPINFOHEADER*)(GlobalLock(hNewDIB));
		  //  Bug or feature?
		  //  ChangeDIBFormat above leaves the biClrUsed field 0.
		  //  According to the doc, this means: "... the bitmap uses the maximum number
		  //  of colors corresponding to the value of the biBitCount member for the
		  //  compression mode specified by biCompression". This works well with the
		  //  standard Media Player, but displays wrong colors in the ActiveMovie player.
		  //  Everything is fine, however, if I manually set this field to 256:
		  pNewDIB->biClrUsed = 256;
		  //  If the stream format (DIB attributes and palette) was never written
		  //  before then do it now:
		  if (!isFormatSet) 
		  {
			  result = AVIStreamSetFormat(videoStream, 0,
					   pNewDIB, pNewDIB->biSize + PaletteSize((LPSTR)pNewDIB)); 
			  if (result != 0) 
			  {
				 ErrorMessage="Can't set format";  
				 goto error;
			  } 
			  isFormatSet = TRUE;
		  } 

		  result = AVIStreamWrite(videoStream, framesWritten, 1,
		   		   FindDIBBits((LPSTR)pNewDIB), pNewDIB->biSizeImage, AVIIF_KEYFRAME, 
				   &lSampWritten, &lBytesWritten);
		  if (result == 0) 
		  {
  		 	framesWritten++;
		  }
	} 
//  Compression failed, continue with the original bitmap:
	
	else 
	{
		  //  If the stream format (DIB attributes and palette) was never written
		  //  before then do it now:
		if (!isFormatSet) 
		{
		 	result = AVIStreamSetFormat(videoStreamCompressed, 0, 
			pDIB,  pDIB->biSize + PaletteSize((LPSTR)pDIB)); 
			if (result != 0) 
			{
				ErrorMessage="Can't set format";  
				goto error;
			} 
			isFormatSet = TRUE;
		}
		result = AVIStreamWrite(videoStreamCompressed, framesWritten, 1,
				 FindDIBBits((LPSTR)pDIB), 
				 pDIB->biSizeImage, AVIIF_KEYFRAME, 
				 &lSampWritten, &lBytesWritten);
		 if (result == 0) 
		 {
  		 	framesWritten++;
		 }
	} 

	if (pDIB) {
		GlobalUnlock(pDIB);
		GlobalFree(pDIB);
	}
	if (hNewDIB) {
		GlobalUnlock(hNewDIB);
		GlobalFree(hNewDIB);
	}
	return result;

error:
	if (pDIB) 
	{
		GlobalUnlock(pDIB);
		GlobalFree(pDIB);
	}
	if (hNewDIB) 
	{
		GlobalUnlock(hNewDIB);
		GlobalFree(hNewDIB);
	}
	if (videoStream)			AVIStreamClose(videoStream);
	if (videoStreamCompressed)	AVIStreamClose(videoStreamCompressed);
	if (aviFile)				AVIFileClose(aviFile);
	AVIFileExit();
	HWND Owner = FindWindow(NULL,"Max04a"); 
	if (result != NOERROR)  	MessageBox(Owner,(LPCTSTR)ErrorMessage,NULL,MB_OK | MB_ICONERROR);
	return result;
}


__declspec(dllexport) int CLOSEAVIFILE()
/*
		Closes an open AVI file, including any open video stream.
		Can be used to clean up when an error occurs during writing.
*/
{
	if (videoStream != NULL) {
		AVIStreamRelease(videoStream);
		videoStream  = NULL;
	}
	if (videoStreamCompressed != NULL) {
		AVIStreamRelease(videoStreamCompressed);
		videoStreamCompressed = NULL;
	}
	if (aviFile != NULL) {
		AVIFileClose(aviFile);
		aviFile = NULL;
	}
  if (isInitialized) {
	  AVIFileExit();
	  isInitialized = FALSE;
  }
	return 0;
}

